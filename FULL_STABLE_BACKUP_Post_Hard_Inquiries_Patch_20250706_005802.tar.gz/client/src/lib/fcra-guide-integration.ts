// Client-side FCRA/FDCPA Guide Integration
export const FCRA_VIOLATION_TEMPLATES = {
  1: {
    title: "Inaccurate Reporting of Paid/Settled Debts",
    reason: "This account was paid in full",
    instruction: "My credit report shows an outstanding balance owed to this creditor. This account was paid in full, and no further amount is due. Please update to reflect zero balance.",
    legalCitation: "FCRA Section 623(a)(2)"
  },
  2: {
    title: "Reporting of Accounts Discharged in Bankruptcy", 
    reason: "This account was discharged in bankruptcy",
    instruction: "This account was discharged in a bankruptcy. I am requesting that this account be updated to reflect a zero balance per FCRA Section 605(a)(1).",
    legalCitation: "FCRA Section 605(a)(1)"
  },
  3: {
    title: "Mixed Credit Information",
    reason: "This information does not belong to me",
    instruction: "My credit report shows accounts and information that does not belong to me. I believe that my credit file has been mixed with someone else's file. Please verify and remove all incorrect information.",
    legalCitation: "FCRA Section 611(a)"
  },
  4: {
    title: "Incorrect Late Payments",
    reason: "These payments were made on time",
    instruction: "My credit report is showing late payments that were actually made on time. I am requesting that the late payment markings be updated to reflect accurate payment history.",
    legalCitation: "FCRA Section 623(a)(2)"
  },
  5: {
    title: "Duplicate Accounts",
    reason: "This account is listed multiple times",
    instruction: "My credit report shows the same debt listed multiple times. I am requesting that the duplicate accounts be removed to prevent double jeopardy.",
    legalCitation: "FCRA Section 623(a)(2)"
  },
  9: {
    title: "Outdated Account (7+ Years)",
    reason: "This account is older than 7 years",
    instruction: "My credit report shows negative information older than 7 years. Per FCRA Section 605(a)(4), this outdated information must be removed immediately.",
    legalCitation: "FCRA Section 605(a)(4)"
  },
  10: {
    title: "Debt Buyer and Original Creditor Double Reporting",
    reason: "Both debt buyer and original creditor are reporting",
    instruction: "My credit report shows both the debt buyer and original creditor reporting the same balance. This constitutes double jeopardy and one of these duplicate balances must be removed.",
    legalCitation: "FCRA Section 623"
  }
};

export const FDCPA_TEMPLATE_LETTERS = {
  ceaseAndDesist: {
    title: "Cease and Desist Letter",
    template: `[Date]

[Debt Collector Name]
[Address]

Re: Account Number: [Account Number]

Dear Collector,

This letter is to formally notify you that I am invoking my rights under the Fair Debt Collection Practices Act (FDCPA), 15 U.S.C. § 1692c(c), to request that you cease and desist all communication with me regarding the above-referenced account.

I do not wish to be contacted by phone, mail, email, text message, or any other form of communication regarding this matter.

This is not an acknowledgment of the validity of this debt. I am exercising my right to stop harassment under federal law.

Sincerely,
[Your Name]`
  },
  
  debtValidation: {
    title: "Debt Validation Request",
    template: `[Date]

[Debt Collector Name]  
[Address]

Re: Account Number: [Account Number]

Dear Collector,

I am writing in response to your recent contact regarding the above debt. Under the Fair Debt Collection Practices Act (FDCPA), 15 U.S.C. § 1692g, I have the right to request validation of this debt.

Please provide the following documentation:
1. Proof that you own this debt or have been assigned this debt
2. Copy of the original contract or agreement creating this debt
3. Account statements showing charges, payments, and current balance
4. Proof of your authority to collect this debt in my state

Until you provide proper validation, you must cease all collection activities on this account.

Sincerely,
[Your Name]`
  }
};

export function detectViolationFromAccountData(account: any): { violationType: number | null, confidence: number, evidence: string[] } {
  const evidence = [];
  let violationType = null;
  let confidence = 0;

  // Check for paid but still showing balance (Violation #1)
  if (account['@_AccountStatusType']?.toLowerCase().includes('paid') && 
      parseFloat(account['@_CurrentBalance'] || '0') > 0) {
    violationType = 1;
    confidence = 0.9;
    evidence.push('Account marked as paid but shows outstanding balance');
  }

  // Check for bankruptcy discharge (Violation #2)
  if (account['@_AccountStatusType']?.toLowerCase().includes('bankruptcy') ||
      account['@_AccountStatusType']?.toLowerCase().includes('discharged')) {
    violationType = 2;
    confidence = 0.8;
    evidence.push('Account appears to be bankruptcy-related');
  }

  // Check for outdated accounts (Violation #9) 
  const currentDate = new Date();
  const accountDate = new Date(account['@_DateClosed'] || account['@_DateOpened']);
  const yearsDiff = (currentDate.getTime() - accountDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
  
  if (yearsDiff > 7 && (account['@_AccountStatusType']?.includes('Collection') || 
                        account['@_AccountStatusType']?.includes('Charge'))) {
    violationType = 9;
    confidence = Math.min(0.9, yearsDiff / 10); // Higher confidence for older accounts
    evidence.push(`Account is ${Math.floor(yearsDiff)} years old and still reporting negatively`);
  }

  // Check for duplicate reporting patterns (Violation #10)
  if (account._CREDITOR?.['@_Name']?.toLowerCase().includes('acquisition') ||
      account._CREDITOR?.['@_Name']?.toLowerCase().includes('recovery') ||
      account._CREDITOR?.['@_Name']?.toLowerCase().includes('collection')) {
    violationType = 10;
    confidence = 0.6;
    evidence.push('Appears to be debt buyer/collection account - check for original creditor duplication');
  }

  return { violationType, confidence, evidence };
}

export function generateGuideBasedDispute(violationType: number, creditorName: string): { reason: string, instruction: string, citation: string } {
  const template = FCRA_VIOLATION_TEMPLATES[violationType as keyof typeof FCRA_VIOLATION_TEMPLATES];
  
  if (!template) {
    return {
      reason: "This account contains inaccuracies",
      instruction: "Please investigate and correct this account information",
      citation: "FCRA Section 611"
    };
  }

  return {
    reason: template.reason,
    instruction: template.instruction.replace('[Creditor]', creditorName),
    citation: template.legalCitation
  };
}