/**
 * Shared type definitions for credit report components
 */

export interface SavedDispute {
  reason: string;
  instruction: string;
  violations?: string[];
}

export interface SavedDisputes {
  [accountId: string]: boolean | SavedDispute;
}

export interface AiViolations {
  [accountId: string]: string[];
}

export interface CreditData {
  CREDIT_RESPONSE?: {
    CREDIT_LIABILITY?: any[];
    CREDIT_INQUIRY?: any[];
    CREDIT_PUBLIC_RECORD?: any[];
  };
  [key: string]: any;
}

export interface BaseComponentProps {
  creditData: CreditData;
  savedDisputes: SavedDisputes;
  aiViolations: AiViolations;
  aiScanCompleted: boolean;
  onDisputeSaved: (disputeData: any) => void;
  onHeaderReset?: () => void;
}

export interface ExpandableComponentProps extends BaseComponentProps {
  isExpanded: boolean;
  setIsExpanded: (expanded: boolean) => void;
}

export interface SectionComponentProps extends BaseComponentProps {
  showSection: boolean;
  setShowSection: (show: boolean) => void;
}

export interface AccountSectionProps extends SectionComponentProps {
  expandAll: boolean;
  setExpandAll: (expand: boolean) => void;
  showAllDetails: boolean;
  setShowAllDetails: (show: boolean) => void;
  userHasManuallyExpanded: boolean;
  setUserHasManuallyExpanded: (expanded: boolean) => void;
}