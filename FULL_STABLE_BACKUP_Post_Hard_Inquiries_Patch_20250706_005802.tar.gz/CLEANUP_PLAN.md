# CreditAppMUI-2 Systematic Cleanup Plan
## Generated: June 28, 2025

## Phase 1: Critical React Hooks Violations (IMMEDIATE)
### Files with Conditional Hook Usage:
- `account-row-final.tsx` - Line 49, 55: useEffect, useState called conditionally
- `account-row-fixed.tsx` - Line 102: useCallback called conditionally  
- `account-row-minimal.tsx` - Line 134: useCallback called conditionally
- `account-row-stable.tsx` - Line 110: useCallback called conditionally

**Impact:** These cause React runtime errors and app crashes

## Phase 2: Remove Duplicate/Experimental Components
### Account Row Variants to Delete:
- `account-row-collapsed.tsx` - Experimental version
- `account-row-expanded.tsx` - Experimental version  
- `account-row-final.tsx` - Has critical React violations
- `account-row-fixed.tsx` - Has conditional hooks
- `account-row-minimal.tsx` - Has conditional hooks
- `account-row-stable.tsx` - Has conditional hooks

**Keep:** `account-row.tsx` (main working component)

## Phase 3: Unused Dependencies Cleanup
### 49 Unused Dependencies to Remove:
- @anthropic-ai/sdk, @hookform/resolvers, @jridgewell/trace-mapping
- @radix-ui/react-* (multiple unused components)
- chromium, cmdk, connect-pg-simple, date-fns
- embla-carousel-react, framer-motion, input-otp
- memorystore, next-themes, passport*, puppeteer-core
- react-day-picker, react-hook-form, react-icons
- react-resizable-panels, recharts, vaul
- zod-validation-error, tw-animate-css

## Phase 4: TypeScript Quality Improvements
### Fix 50+ `any` Types:
- Replace `any` with proper interfaces in credit-summary.tsx
- Add type definitions for account data structures
- Fix missing type imports for assets

## Phase 5: Code Quality Cleanup
### Remove Debug Code:
- 150+ console.log statements across components
- Unused variables and imports
- JSX unescaped entities

## Phase 6: Asset Optimization
### Missing Asset Files:
- Fix import paths for bureau logos
- Add missing score-gauge-arc.png
- Clean up unused asset references

## Estimated Impact:
- **Bundle Size:** -40MB (removing unused deps)
- **Build Time:** -30% (fewer dependencies to process)
- **Code Quality:** Eliminate all ESLint errors
- **Stability:** Fix React hooks violations preventing crashes