// Script to measure the exact positions and calculate midpoint
console.log('Measuring positions...');

// Find the "Inquiries older than 24 months do not impact the score" text
const headerText = Array.from(document.querySelectorAll('p')).find(p => 
  p.textContent.includes('Inquiries older than 24 months do not impact the score')
);

// Find the "Older Inquiries" white box (Card element)
const olderInquiriesCard = Array.from(document.querySelectorAll('[class*="Card"]')).find(card => {
  const text = card.textContent;
  return text.includes('27 Older Inquiries') || text.includes('Older Inquiries');
});

if (headerText && olderInquiriesCard) {
  const headerRect = headerText.getBoundingClientRect();
  const cardRect = olderInquiriesCard.getBoundingClientRect();
  
  const headerBottom = headerRect.bottom;
  const cardTop = cardRect.top;
  const distance = cardTop - headerBottom;
  const midpoint = headerBottom + (distance / 2);
  
  console.log('Header text bottom Y:', headerBottom);
  console.log('Card top Y:', cardTop);
  console.log('Distance between:', distance + 'px');
  console.log('Midpoint Y:', midpoint);
  console.log('Distance from header bottom to midpoint:', (distance / 2) + 'px');
} else {
  console.log('Could not find elements');
  console.log('Header text found:', !!headerText);
  console.log('Card found:', !!olderInquiriesCard);
}
